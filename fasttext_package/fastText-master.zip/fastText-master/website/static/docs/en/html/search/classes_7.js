var searchData=
[
  ['qmatrix',['QMatrix',['../classfasttext_1_1QMatrix.html',1,'fasttext']]]
];

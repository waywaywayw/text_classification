var searchData=
[
  ['cbow',['cbow',['../namespacefasttext.html#a349df214746a2ea0e5d7c26326b03d6fae4709295b2cc44d67facf32b1099f1af',1,'fasttext']]]
];
